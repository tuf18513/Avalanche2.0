To run this game:
1. got to nodejs.org/
2. download v7.9.0
3. install v7.9.0
4. open a terminal window(on windows click the start icob, type cmd and hit enter)
5. type cd then the space character
6. drag and drop the Avalanche folder into the window(make sure it is unzipped), then hit enter.
7. type in node server.js then hit enter.
8. open up your favorite web browser and navigate to http://localhost:3000/ 
9. to start the game currently you need two instances of it running, so you will have to repeat step 8 in a second tab.